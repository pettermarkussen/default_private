# About-siden som tabeller – oppskrift

**Anbefaling:** Bytt ut tekstblokkene med fire tabellvisualer, slik skissen viser. Det trengs ingen modellendring.

| Tabell | Kolonner | Dynamisk |
|---|---|---|
| **Definitions** | Figure · What it means · **Today** · Source · date used | *Today* viser dagens tall for hver definisjon, for eksempel forecast, spenn, pipeline og ordreinngang. Tallene følger tilgangen til den som ser rapporten. |
| **Data freshness** | ● · Source · Latest data · Status | Prikk og status blir grønne, ravgule eller røde etter hvor mange arbeidsdager siden siste data. |
| **Left out of all figures** | What · Why | – |
| **Known issues** | Status · Issue | Statusen vises som en farget etikett: rav for open, grå for planned og grønn for handled. |

**Slik virker det.** En tabellvisual trenger rader, og rapporten har ingen tabell med definisjoner. Derfor brukes `DIM_Dates[Day]` (1–31) som radnummer. Hver kolonne er et tekstmål med `SWITCH` som returnerer innholdet for radnummeret. Rader der alle målene er tomme, forsvinner. Radnummer-kolonnen gjøres smal og hvit, slik at den ikke vises.

Velg alternativ A hvis du ikke har endret noe i Desktop siden v2.0.1. Velg B hvis du har det, eller vil bygge selv.

---

## A. Ferdige filer (5 minutter)

1. Ta en kopi av prosjektmappen.
2. Slett mappen `definition` inne i `Business Review 2.0.Report`, og kopier inn `A - ferdige filer/Trinn 1/definition`.
3. Åpne `.pbip`. About-siden har nå de fire tabellene.

Bare to ting er endret fra v2.0.1: mappen `pages/about` og `reportExtensions.json`, som har fått 15 nye mål. Resten er identisk. Vil du bare bytte disse to, sletter du først den gamle `about`-mappen og kopierer så inn den nye.

Etter modellendringen bruker du `A - ferdige filer/Trinn 2/definition` i stedet for `Etter modellendring/definition` fra v2.0.1. Da har definisjonene også radene *Scenario* og *What changed*.

---

## B. For hånd i Desktop (30–45 minutter)

### 1. Lag de 15 målene
Åpne `B - for hånd/About_maal_ny_maaling.txt`. Velg tabellen `00_Measures` → **Nytt mål** (*New measure*), og lim inn ett mål om gangen. Ta med alt fra navnet og ned til tomlinjen. Sett visningsmappen (*Display folder*) som står over hvert mål.

Vil du se resultatet først, kjør `About_maal_test.dax` i DAX query view med rapporten åpen. Da får du de fire tabellene som resultat.

### 2. Lag de fire tabellene
Sett inn en **Tabell** (*Table*). Legg inn `DIM_Dates[Day]` først. Velg **Ikke oppsummer** (*Don't summarize*) i feltlisten, og sett deretter inn målene i rekkefølgen under. Sorter tabellen på `Day`, stigende (… → *Sort by* → Day → *Sort ascending*).

| Tabell | Plassering (X, Y, B, H) | Felt i rekkefølge → kolonnetittel (bredde) |
|---|---|---|
| Definitions | 16, 106, 800, 608 | Day → « » (smal) · `BR About def figure` → Figure (128) · `BR About def text` → What it means (372) · `BR About def today` → Today (120) · `BR About def source` → Source · date used (140) |
| Data freshness | 828, 106, 436, 178 | Day → « » · `BR About fresh dot` → « » (22) · `BR About fresh source` → Source (140) · `BR About fresh date` → Latest data (116) · `BR About fresh status` → Status (124) |
| Left out of all figures | 828, 296, 436, 196 | Day → « » · `BR About excl what` → What (200) · `BR About excl why` → Why (196) |
| Known issues | 828, 504, 436, 210 | Day → « » · `BR About issue status` → Status (72) · `BR About issue text` → Issue (324) |

Gi kolonnene nytt navn med høyreklikk i feltlisten → **Gi nytt navn for dette visualobjektet** (*Rename for this visual*). Radnummeret får et mellomrom som navn. Bredden justerer du ved å dra i kolonnekanten.

### 3. Formatering (lik for alle fire)
| Format → | Innstilling |
|---|---|
| Stilforhåndsinnstillinger (*Style presets*) | Ingen (*None*) |
| Rutenett (*Grid*) | Loddrette linjer av. Vannrette linjer på, farge #ECECEE. Utfylling for rader (*Row padding*) 5. |
| Verdier (*Values*) | Skrift 9. Tekstfarge #4D4D51. Bakgrunn og alternativ bakgrunn hvit. **Tekstbryting på** (*Text wrap*). |
| Kolonneoverskrifter (*Column headers*) | Segoe UI Semibold 8, farge #656568, tekstbryting på |
| Totaler (*Totals*) | Av |
| Bestemt kolonne (*Specific column*) | `Day`: tekstfarge hvit. Figure, Source og Latest data: #333337. Source · date used: #656568. Today: justering høyre. |
| Generelt → Tittel (*General → Title*) | Tittel på (11 pt, #333337). Undertittel på (8–9 pt, #656568). Tekstene står under. |
| Generelt → Effekter (*General → Effects*) | Bakgrunn hvit. Visuell kantlinje #E4E4E6. |

Undertitler:
- Definitions: *One definition per figure · 'Today' follows your access (the regions you can see) · MNOK unless stated otherwise*
- Data freshness: *Latest record per source in working days · green: today or previous working day · amber: 2–3 · red: older*
- Left out of all figures: *One list for the whole report · owner: Finance*
- Known issues: *What is not right yet, and the status*

### 4. Betinget formatering (Celleelementer → fx → Feltverdi / *Cell elements → fx → Field value*)
- **Data freshness**, kolonne «●»: skriftfarge = `BR Clr About fresh dot`. Juster midtstilt.
- **Data freshness**, kolonne Status: skriftfarge = `BR Clr About fresh status`.
- **Known issues**, kolonne Status: bakgrunnsfarge = `BR Clr About issue`. Tekstfarge hvit, midtstilt (Bestemt kolonne).

### 5. Rydd
Slett de gamle tekstboksene og kortene på siden: definisjonsboksen, ferskhetsboksen med kortene, boksen *Left out of all figures* og boksen *Known issues*.

---

## Vedlikehold
- **Endre en tekst:** rett linjen i målet. Raden har samme nummer i alle målene til samme tabell. Rad 8 i Definitions er for eksempel *Forecast* i alle fire `BR About def …`-målene.
- **Legge til en rad:** legg til det neste nummeret i alle målene til tabellen. Inntil 31 rader per tabell.

## Neste steg
Gjør det samtidig med modellendringen. Flytt innholdet til en liten tabell i lakehouse, for eksempel `br_about` med kolonnene Section, Order, Figure, Text og Source, som økonomi eier og vedlikeholder. Tabellvisualene blir de samme, men feltene byttes til kolonnene i tabellen. Da kan definisjoner og utelatelser endres uten å røre rapporten.
