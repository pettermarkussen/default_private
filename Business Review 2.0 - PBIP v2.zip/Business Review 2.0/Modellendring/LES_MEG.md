# Modellendring for Business Review 2.0 v2

Gjøres i DEV først. Tar 30–45 minutter. Ingen eksisterende tabeller, relasjoner eller mål endres. Det kommer bare til sju nye tabeller og to nye relasjoner.

| Side | Trenger | Hvorfor |
|---|---|---|
| Scenarios | Fem små parametertabeller (`br_scn_*`) | Direct Lake tillater ikke what-if-parametre eller kalkulerte tabeller. Knappene må ha en tabell å filtrere. |
| What changed | Daglige øyeblikksbilder (`br_snap_*`) | Modellen viser bare dagens tall. For å sammenligne med forrige uke må noe lagre tallene hver dag. |

Resten av rapporten virker uten endringen.

## Innhold i mappen

| Fil | Hva |
|---|---|
| `BR_setup_scenario_tables.ipynb` | Lager de fem parametertabellene. Kjøres én gang. Inneholder ingen bedriftsdata. |
| `BR_daily_snapshot.ipynb` | Tar øyeblikksbildet hver morgen og regner ut hva som har endret seg. Planlegges daglig. |
| `snapshot_queries.dax` | DAX-en notebooken sender til modellen. Kan kjøres i DAX query view for kontroll. |

## Steg for steg

**1. Importer notebookene**
Åpne arbeidsområdet i Fabric og velg *Import → Notebook → From this computer*. Velg begge `.ipynb`-filene.

**2. Koble til lakehouse**
Åpne hver notebook. I *Lakehouse explorer* til venstre: *Add* → *Existing lakehouse* → velg lakehouse-et salgsmodellen leser fra. Det må stå som standard (default).
Er du usikker på hvilket lakehouse det er: åpne semantikkmodellen og se på kilden til `f_customerorderrows`.

**3. Lag parametertabellene**
Kjør `BR_setup_scenario_tables` (*Run all*). Den skriver ut fem tabeller med antall rader: 3, 5, 5, 25 og 6.

**4. Prøvekjør øyeblikksbildet**
Åpne `BR_daily_snapshot`. Sett `DRY_RUN = True` i parametercellen og kjør alt. Sjekk utskriften:
- *Forecast … MNOK* skal være lik forecast på Status i dag.
- *sum of regions* skal være lik forecast. Får du `WARNING`, ligger et land under to regioner i `DIM_SalesTarget_1`. Da må det ryddes før siden tas i bruk.

Sett `DRY_RUN = False` og kjør igjen. Første dag står det *No earlier snapshot this year yet*. Det er riktig. Sammenligningen kommer dagen etter.

**5. Legg tabellene til i modellen**
Åpne semantikkmodellen i nettleseren (*Open data model*). Velg *Edit tables* og huk av for disse sju:

- `br_scn_basis`, `br_scn_slippage`, `br_scn_weighting`, `br_scn_grid`, `br_scn_steps`
- `br_snap_bridge`, `br_snap_changes`

Ikke legg til `br_snap_regions`, `br_snap_orders` eller `br_snap_projects`. De er historikk for notebooken. De inneholder ordrer per kunde og skal ikke ligge i modellen.

**6. Sorter etter kolonne**
Velg kolonnen, deretter *Sort by column*:

| Tabell | Kolonne | Sorteres etter |
|---|---|---|
| `br_scn_basis` | `Basis` | `BasisOrder` |
| `br_scn_slippage` | `Slippage` | `SlippageOrder` |
| `br_scn_weighting` | `Weighting` | `WeightingOrder` |
| `br_scn_grid` | `Slippage` | `SlippageOrder` |
| `br_scn_grid` | `Weighting` | `WeightingOrder` |
| `br_scn_steps` | `Step` | `StepOrder` |
| `br_snap_bridge` | `Step` | `StepOrder` |

Uten dette står knappene og stegene i broen i alfabetisk rekkefølge.

**7. Relasjoner (radnivåsikkerhet)**
Lag to relasjoner. De sørger for at en selger med begrenset tilgang bare ser sine regioner på *What changed*:

| Fra | Til | Kardinalitet | Kryssfilter |
|---|---|---|---|
| `DIM_SalesTarget_1[Region_Parent]` | `br_snap_bridge[Region_Parent]` | Mange-til-mange | Én retning: `DIM_SalesTarget_1` filtrerer `br_snap_bridge` |
| `DIM_SalesTarget_1[Region_Parent]` | `br_snap_changes[Region_Parent]` | Mange-til-mange | Én retning: `DIM_SalesTarget_1` filtrerer `br_snap_changes` |

Parametertabellene (`br_scn_*`) skal ikke ha relasjoner.

**8. Skjul hjelpekolonner**
Dette er valgfritt, men det gjør feltlisten ryddigere:

- `br_scn_basis`: `BasisOrder`, `IsOfficial`, `BasisNote`
- `br_scn_slippage`: `SlippageOrder`, `SlippageRate`, `IsOfficial`
- `br_scn_weighting`: `WeightingOrder`, `WeightingRate`, `IsOfficial`
- `br_scn_grid`: `SlippageOrder`, `SlippageRate`, `WeightingOrder`, `WeightingRate`
- `br_scn_steps`: `StepOrder`, `StepKey`
- `br_snap_bridge`: alle unntatt `Step`
- `br_snap_changes`: `snap_date`, `compare_date`, `Region_Parent`, `RowKey`, `Kind`, `Value`

Datatypene skal komme riktig fra lakehouse: datoer som *Date*, `Value` og `*Rate` som *Decimal number*, `*Order` og `IsTotal`/`IsOfficial` som *Whole number*.

**9. Planlegg notebooken**
Åpne `BR_daily_snapshot`, velg *Run → Schedule* og sett den til hver dag kl. 07:30, etter at morgenlasten er ferdig. Den som eier planen, må være *Member* eller *Contributor* i arbeidsområdet. Notebooken må se alle regioner, og radnivåsikkerheten legges på etterpå via relasjonene i steg 7.

Direct Lake leser nye data automatisk når innstillingen *Keep your Direct Lake data up to date* er på. Den står på som standard. Er den slått av, må modellen oppdateres etter notebooken.

**10. Test**
- Kjør `BR_test_v2_2_full.dax` i DAX query view. Resultat 9: *Scenario* skal være lik *Range low*.
- Åpne Scenarios i rapporten. Velg *Last year* og *25 %*. Scenarioet skal være lik den lave enden av spennet på Status.
- Dagen etter første kjøring: *What changed* viser en bro. *Largest changes* summerer til endringen i broen.
- Se rapporten som en selger med begrenset tilgang (*Vis som rolle*). *What changed* skal bare vise selgerens regioner.

## Til PROD
Gjenta stegene mot PROD-lakehouse og PROD-modell etter at Julie har godkjent v2 i DEV. Notebookene har modell-ID-en øverst (`DATASET`). Endre den hvis PROD-modellen har en annen ID.

## Tilbakerulling
Fjern de sju tabellene fra modellen (og eventuelt fra lakehouse), og stopp planen. Scenarios og What changed viser da feil. De andre sidene påvirkes ikke.

## Greit å vite
- **Lagring.** Historikken (`br_snap_regions/orders/projects`) beholdes i 400 dager (`KEEP_DAYS`). Det er noen få tusen rader per dag.
- **Dato.** Notebooken bruker modellens `TODAY()`. I Power BI-tjenesten er det UTC-dato. Kjøring kl. 07:30 norsk tid gir riktig dag.
- **Pipeline i listen over endringer er en tilnærming.** Broen bruker den eksakte endringen i vektet pipeline fra modellen. Prosjektlinjene i listen er beregnet fra `F_Projects` (åpne prosjekter med installasjon i år, mer enn 10 dager fram, × 39 %). Forskjellen havner i *Other changes*.
- **Sammenligning.** Notebooken sammenligner med øyeblikksbildet for omtrent en uke siden. Den sammenligner aldri over et årsskifte. De første dagene i januar sammenlignes det med første øyeblikksbilde i det nye året.
