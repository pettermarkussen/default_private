# Business Review 2.0 – versjon 2

Laget 21.10.2026. Bygger på v1.0.1 og konseptskissene v3. Rapporten er fortsatt tynn og koblet til salgsmodellen `e88a75d1-2c33-4234-b6c1-6054da26f3e4`. Alle mål ligger i rapporten (`reportExtensions.json`, tabell `00_Measures`, mappe *Business Review*).

## Innhold

| Fil / mappe | Hva |
|---|---|
| `Business Review 2.0.pbip` og `Business Review 2.0.Report/` | Rapporten: 7 sider + tooltip-side, 299 rapportmål. `definition.pbir` er **ikke** med (se under). |
| `definition.pbir.mal` | Mal for tilkoblingen. Brukes bare hvis du starter i en tom mappe. |
| `Test/BR_test_v2_1_core.dax` | Test 1: alle mål som virker på dagens modell. Kjøres før noe annet. |
| `Test/BR_test_v2_2_full.dax` | Test 2: alt, inkludert Scenarios og What changed. Kjøres etter modellendringen. |
| `Modellendring/` | To notebooker og steg-for-steg for de nye tabellene (`LES_MEG.md`). |

## Hva er nytt

| Side | Endring |
|---|---|
| **Status** | Spenn på forecast (lav–høy) i nøkkeltallet, i forecast-boksen og som to streker i desember i den kumulative grafen. Knapp til Scenarios. |
| **What changed** (ny) | Bro fra forecast for en uke siden til i dag, gruppert etter årsak: nye ordrer, flyttet til neste år, endret/kansellert, pipeline, run rate, annet. Tabell per region og liste over ordrene og prosjektene bak. |
| **Scenarios** (ny) | Tre knapperader: grunnlag, forskyvning til neste år og pipeline-vekting. Ingen valg betyr offisielle verdier. Bro fra offisiell forecast til scenario, matrise med alle 25 kombinasjoner og tabell per region. Lagres aldri og endrer aldri Status. |
| **Order intake** | Periodevelger på ordredato. Ingen valg betyr i år, og perioden slutter alltid i dag. Siste måned, siste hele uke, 13 uker, regiontabell og største ordrer i kNOK. Delvise måneder vises grå og sammenlignes med de samme dagene i fjor. |
| **Pipeline** | *Overdue* som egen stolpe på samme akse som månedene. Selgervelger. Prosjektlisten er i kNOK og har flagg for passert dato og 90 dager uten oppdatering. |
| **Trend** | Samme periode som Order intake (synket). Rullerende 12 måneder slutter på siste hele måned i perioden. Ordrereserven viser alltid i dag. |
| **About** | Nye definisjoner: spenn, scenario, periode, What changed og enheter. Ferskhet per kilde i arbeidsdager. |
| **Alle sider** | Ferskhetsfirkant i toppen (grønn/rav/rød). Ny statuspalett, der gult bare brukes til markering og aldri til varsel. Filtervalg lagres ikke mellom besøk. |

## Rekkefølge

1. **Kjør `Test/BR_test_v2_1_core.dax`** i DAX query view (Service: åpne modellen → *Skriv DAX-spørringer*).
   - Går den uten feil, virker alle mål unntatt Scenarios og What changed.
   - Resultat 1: *Forecast* skal være lik Status Sales samme dag.
   - *OI in period* skal være lik *OI YTD*, og *OI budget in period* lik *OI budget YTD*. Ingen periode valgt betyr i år.
   - Resultat 3 og 4 viser en egendefinert periode (15. nov i fjor – 10. feb i år). Det er det samme som om noen velger den i periodevelgeren.
2. **Ta en kopi av v1.0.1-mappen.** Har du gjort endringer i Desktop etter v1.0.1, overskrives de i neste steg.
3. **Bytt ut rapportdefinisjonen.** I prosjektmappen din: slett mappene `definition` og `StaticResources` inne i `Business Review 2.0.Report`, og kopier inn de nye. Ikke slå sammen mappene. Gamle visualer ville da ligge igjen og vise feil.
   - Behold din egen `definition.pbir`. Den har tilkoblingen du rettet i v1.0.1.
   - Starter du i en tom mappe, kopier `definition.pbir.mal` til `Business Review 2.0.Report/definition.pbir` og fyll inn navnet på arbeidsområdet og modellen, som i v1.0.1.
4. **Åpne `.pbip` i Desktop.** Status, Order intake, Pipeline, Trend og About virker. Scenarios og What changed viser feil til modellendringen er gjort.
5. **Modellendring i DEV** – se `Modellendring/LES_MEG.md`.
6. **Kjør `Test/BR_test_v2_2_full.dax`** og testlisten under. Publiser etterpå.

## Test i Desktop

- **Status.** Forecast-kortet viser *Range a–b · see Scenarios*. Hold musen over forecast-tallet: regnestykket og spennet vises. Knappen *Test scenarios →* går til Scenarios. Den kumulative grafen har to streker i desember.
- **What changed.** Dagen etter første kjøring av notebooken: broen starter på forecast for en uke siden og slutter på dagens. *Forecast now* er lik Status, eller forklarer forskjellen. Listen summerer til broen.
- **Scenarios.** Ingen valg gir scenario = offisiell. *Last year* + *25 %* gir den lave enden av spennet. *Firm orders* gjør vektingen uaktuell (notatet sier det). I matrisen er valgt kombinasjon gul og offisiell grå. *Reset to official* tømmer valgene.
- **Order intake.** Velg 15. nov – 10. feb: november og februar blir grå. Titler, kort og tabeller følger perioden. *No budget for …* vises når budsjettet mangler for deler av perioden. *Reset* går tilbake til i år.
- **Trend.** Endre periode på Order intake: Trend følger etter. Grafen med 12 måneder slutter på siste hele måned.
- **Pipeline.** *Overdue*-stolpen og månedene har samme skala. Selgervelgeren filtrerer kort, grafer og liste.
- **RLS.** Se rapporten som en selger med begrenset tilgang (*Vis som rolle*).

## Valg jeg har tatt

| Punkt | Valg | Hvorfor |
|---|---|---|
| Periodevelger | `DIM_Dates_1[Date]` (ordredato). Ingen valg betyr 1. januar – i dag. | Kalenderen filtrerer bare ordrelinjer, budsjett og prosjekter. Fakturaer og leveringsdatoer påvirkes ikke. Egen periodekalender trengs ikke. |
| *Reset*-knappene | Tømmer alle velgere på siden, også region. | Power BI kan ikke nullstille én enkelt velger uten bokmerker. Hver velger har også et viskelær i toppen. |
| Spenn | Lav: fjorårets forskyvning (10,9 % Americas, 0,3 % resten) og pipeline 25 %. Høy: pipeline 50 %. | Samme som i skissene. Tallene ligger fast i målene `BR Slippage LY`, `BR Forecast low` og `BR Forecast high`. Definisjonen bør avklares med Julie før lansering. |
| Ukeaksen på Order intake | `DIM_Dates[Start_of_Week]` som akse. Ordreinngangen regnes fortsatt på ordredato. | Med ordredatokalenderen som akse ville periodevelgeren skjult ukene utenfor perioden. |
| Filtervalg mellom besøk | Lagres ikke (*persistent filters* av). | Scenarioer skal ikke henge igjen, og perioden skal starte på i år. |
| Statusfarger | Grønn #1E9E5A, rav #C2700A, rød #D64545 (tekst: #1A7F37, #A15C07, #D1242F). | Vestre-gul er merkefargen og skal ikke bety varsel. Temaet er oppdatert. |

## Ikke med i v2

- Drillthrough til regiondetalj, hjelpemodus med bokmerker og mobiloppsett.
- Lastetidspunkt per kilde. Ferskheten bruker siste registrerte dato i Monitor og Lime.

## Ting jeg ikke kunne teste her

Jeg har ikke Power BI Desktop eller tilgang til modellen. Dette er kontrollert:

- Alle filer er validert mot Microsofts PBIR-skjemaer.
- Formateringsegenskapene er sjekket mot temaskjemaet.
- Alle tabell-, kolonne- og målnavn er sjekket mot modellens metadata. De nye tabellene er sjekket mot planen i `Modellendring/LES_MEG.md`.
- Rapportmålene er sjekket for syntaks og referanser. Ingen av målene på de fem gamle sidene avhenger av de nye tabellene.
- Notebooken er kjørt i en simulering over to dager, med testdata. Broen og listen avstemmer per region.

Dette må verifiseres i Desktop:

- **Knappevelgeren på Scenarios** (nytt visual): avstand og gul markering av offisiell verdi.
- **Periodevelgeren** viser hele datoperioden i modellen når ingenting er valgt. Titlene og tekstene sier hvilken periode som vises.
- **Broene** (stablet søylediagram med usynlig base): at akse-start fra mål (fx) tas i bruk og at basen er usynlig.
- **`NETWORKDAYS`** brukes i ferskheten. Funksjonen kom i 2023 og skal virke i tjenesten.
- **Ytelse:** *Largest orders* og ukegrafen. Ta en titt i Performance Analyzer.
